export interface Transaction {
  transaction_id: string;
  sender_upi_id: string;
  receiver_upi_id: string;
  amount: number;
  timestamp: string;
  location: string;
  device: string;
  transaction_type: string;
  previous_transactions_count: number;
  average_transaction_amount: number;
  account_age_days: number;
  receiver_risk_score: number;
}

export interface ProcessedResult {
  transaction: Transaction;
  fraudProbability: number;
  isFraudulent: boolean;
}

export type PredictionResults = ProcessedResult[];