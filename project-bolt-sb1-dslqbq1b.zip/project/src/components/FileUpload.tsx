import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload } from 'lucide-react';
import Papa from 'papaparse';
import { Transaction } from '../types';

interface FileUploadProps {
  onDataProcessed: (data: Transaction[]) => void;
}

export function FileUpload({ onDataProcessed }: FileUploadProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      Papa.parse(file, {
        complete: (results) => {
          const transactions: Transaction[] = results.data
            .filter((row: any) => 
              row.transaction_id &&
              row.sender_upi_id &&
              row.receiver_upi_id &&
              row.amount &&
              row.timestamp &&
              row.location &&
              row.device &&
              row.transaction_type &&
              row.previous_transactions_count &&
              row.average_transaction_amount &&
              row.account_age_days &&
              row.receiver_risk_score
            )
            .map((row: any) => ({
              transaction_id: String(row.transaction_id),
              sender_upi_id: String(row.sender_upi_id),
              receiver_upi_id: String(row.receiver_upi_id),
              amount: parseFloat(row.amount),
              timestamp: String(row.timestamp),
              location: String(row.location),
              device: String(row.device),
              transaction_type: String(row.transaction_type),
              previous_transactions_count: parseInt(row.previous_transactions_count),
              average_transaction_amount: parseFloat(row.average_transaction_amount),
              account_age_days: parseInt(row.account_age_days),
              receiver_risk_score: parseInt(row.receiver_risk_score)
            }))
            .filter(transaction => 
              !isNaN(transaction.amount) && 
              !isNaN(transaction.previous_transactions_count) &&
              !isNaN(transaction.average_transaction_amount) &&
              !isNaN(transaction.account_age_days) &&
              !isNaN(transaction.receiver_risk_score)
            );

          if (transactions.length > 0) {
            onDataProcessed(transactions);
          } else {
            alert('No valid transactions found in the CSV file. Please check the format.');
          }
        },
        header: true,
        skipEmptyLines: true,
        error: (error) => {
          alert('Error reading CSV file: ' + error.message);
        }
      });
    }
  }, [onDataProcessed]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'text/csv': ['.csv'],
    },
    maxFiles: 1,
  });

  return (
    <div>
      <div
        {...getRootProps()}
        className={`p-10 border-2 border-dashed rounded-lg cursor-pointer transition-colors
          ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center justify-center text-gray-600">
          <Upload className="w-12 h-12 mb-4" />
          {isDragActive ? (
            <p>Drop the CSV file here...</p>
          ) : (
            <>
              <p className="font-medium">Drop your CSV file here, or click to select</p>
              <p className="text-sm mt-2 text-gray-500">Only CSV files are supported</p>
            </>
          )}
        </div>
      </div>
      <div className="mt-4 text-sm text-gray-600">
        <p className="font-medium">CSV Format Requirements:</p>
        <ul className="list-disc list-inside mt-2">
          <li>Required columns: transaction_id, sender_upi_id, receiver_upi_id, amount, timestamp, location, device, transaction_type, previous_transactions_count, average_transaction_amount, account_age_days, receiver_risk_score</li>
          <li>Numerical fields: amount, previous_transactions_count, average_transaction_amount, account_age_days, receiver_risk_score</li>
          <li>Text fields: All other fields</li>
        </ul>
      </div>
    </div>
  );
}