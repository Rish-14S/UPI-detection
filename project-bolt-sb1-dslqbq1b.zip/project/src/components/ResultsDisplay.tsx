import React from 'react';
import { AlertTriangle, ShieldCheck } from 'lucide-react';
import { PredictionResults } from '../types';

interface ResultsDisplayProps {
  results: PredictionResults;
}

export function ResultsDisplay({ results }: ResultsDisplayProps) {
  const fraudCount = results.filter(r => r.isFraudulent).length;
  const legitimateCount = results.length - fraudCount;

  return (
    <div className="w-full">
      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="p-4 bg-red-50 rounded-lg">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-500 mr-2" />
            <h3 className="font-medium">Fraudulent Transactions</h3>
          </div>
          <p className="text-2xl font-bold text-red-600 mt-2">{fraudCount}</p>
        </div>
        <div className="p-4 bg-green-50 rounded-lg">
          <div className="flex items-center">
            <ShieldCheck className="w-5 h-5 text-green-500 mr-2" />
            <h3 className="font-medium">Legitimate Transactions</h3>
          </div>
          <p className="text-2xl font-bold text-green-600 mt-2">{legitimateCount}</p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full bg-white rounded-lg overflow-hidden">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Transaction ID</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sender</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Receiver</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Risk Score</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fraud Probability</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {results.map((result) => (
              <tr key={result.transaction.transaction_id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                    ${result.isFraudulent ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                    {result.isFraudulent ? 'Fraudulent' : 'Legitimate'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">{result.transaction.transaction_id}</td>
                <td className="px-6 py-4 whitespace-nowrap">₹{result.transaction.amount.toLocaleString()}</td>
                <td className="px-6 py-4 whitespace-nowrap">{result.transaction.sender_upi_id}</td>
                <td className="px-6 py-4 whitespace-nowrap">{result.transaction.receiver_upi_id}</td>
                <td className="px-6 py-4 whitespace-nowrap">{result.transaction.receiver_risk_score}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${result.isFraudulent ? 'bg-red-600' : 'bg-green-600'}`}
                      style={{ width: `${(result.fraudProbability * 100).toFixed(1)}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-gray-500 mt-1">
                    {(result.fraudProbability * 100).toFixed(1)}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}