import React, { useState, useEffect } from 'react';
import { FileUpload } from './components/FileUpload';
import { ResultsDisplay } from './components/ResultsDisplay';
import { Transaction, PredictionResults } from './types';
import { createAndTrainModel, predictFraud } from './ml/model';
import { Shield } from 'lucide-react';
import * as tf from '@tensorflow/tfjs';

function App() {
  const [model, setModel] = useState<tf.LayersModel | null>(null);
  const [results, setResults] = useState<PredictionResults>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function initModel() {
      const newModel = await createAndTrainModel();
      setModel(newModel);
    }
    initModel();
  }, []);

  const handleDataProcessed = async (transactions: Transaction[]) => {
    if (!model) return;
    
    setLoading(true);
    
    const processedResults = transactions.map(transaction => {
      const fraudProbability = predictFraud(model, transaction);
      return {
        transaction,
        fraudProbability,
        isFraudulent: fraudProbability > 0.7
      };
    });
    
    setResults(processedResults);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Shield className="w-12 h-12 text-blue-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            UPI Fraud Detection System
          </h1>
          <p className="text-gray-600">
            Upload your transaction data to analyze potential fraud risks
          </p>
        </div>

        <div className="bg-white shadow rounded-lg p-6 mb-8">
          <FileUpload onDataProcessed={handleDataProcessed} />
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Analyzing transactions...</p>
          </div>
        ) : results.length > 0 ? (
          <div className="bg-white shadow rounded-lg p-6">
            <ResultsDisplay results={results} />
          </div>
        ) : null}
      </div>
    </div>
  );
}

export default App;