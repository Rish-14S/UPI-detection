import * as tf from '@tensorflow/tfjs';
import { Transaction } from '../types';

// Feature normalization constants
const AMOUNT_MAX = 100000;
const PREV_TRANS_MAX = 1000;
const AVG_AMOUNT_MAX = 100000;
const AGE_DAYS_MAX = 3650;
const RISK_SCORE_MAX = 100;

export async function createAndTrainModel() {
  const model = tf.sequential();
  
  // Input layer with same features as XGBoost model
  model.add(tf.layers.dense({
    units: 128,
    activation: 'relu',
    inputShape: [8], // Numerical + encoded categorical features
  }));
  
  // Hidden layers similar to XGBoost tree depth
  model.add(tf.layers.dropout({ rate: 0.3 }));
  model.add(tf.layers.dense({
    units: 64,
    activation: 'relu',
  }));
  
  model.add(tf.layers.dropout({ rate: 0.3 }));
  model.add(tf.layers.dense({
    units: 32,
    activation: 'relu',
  }));
  
  // Output layer for binary classification
  model.add(tf.layers.dense({
    units: 1,
    activation: 'sigmoid',
  }));

  model.compile({
    optimizer: tf.train.adam(0.001),
    loss: 'binaryCrossentropy',
    metrics: ['accuracy'],
  });

  return model;
}

export function preprocessTransaction(transaction: Transaction): number[] {
  // Normalize numerical features (similar to StandardScaler)
  const numericalFeatures = [
    transaction.amount / AMOUNT_MAX,
    transaction.previous_transactions_count / PREV_TRANS_MAX,
    transaction.average_transaction_amount / AVG_AMOUNT_MAX,
    transaction.account_age_days / AGE_DAYS_MAX,
    transaction.receiver_risk_score / RISK_SCORE_MAX,
  ];

  // Encode categorical features (similar to LabelEncoder)
  const locationCode = hashString(transaction.location) % 3;
  const deviceCode = hashString(transaction.device) % 3;
  const transactionTypeCode = hashString(transaction.transaction_type) % 4;

  return [
    ...numericalFeatures,
    locationCode / 3, // Normalize to [0,1]
    deviceCode / 3,
    transactionTypeCode / 4,
  ];
}

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash = hash & hash;
  }
  return Math.abs(hash);
}

export function predictFraud(model: tf.LayersModel, transaction: Transaction): number {
  // XGBoost-like feature importance weighting
  let baseScore = 0;
  
  // High-impact features (similar to XGBoost feature importance)
  if (transaction.amount > 50000) baseScore += 0.4;
  if (transaction.receiver_risk_score > 80) baseScore += 0.3;
  if (transaction.previous_transactions_count < 5) baseScore += 0.2;
  if (transaction.account_age_days < 30) baseScore += 0.2;
  if (transaction.amount > transaction.average_transaction_amount * 3) baseScore += 0.3;
  
  // Neural network prediction
  const preprocessed = preprocessTransaction(transaction);
  const nnPrediction = model.predict(tf.tensor2d([preprocessed])) as tf.Tensor;
  const nnScore = nnPrediction.dataSync()[0];
  
  // Ensemble prediction (combine base score with neural network)
  const finalScore = (baseScore * 0.6) + (nnScore * 0.4);
  
  // Ensure score is between 0 and 1
  return Math.min(Math.max(finalScore, 0), 1);
}